// Copyright 2015 Citra Emulator Project
// Licensed under GPLv2 or any later version
// Refer to the license.txt file included.

// Includes the MicroProfile implementation in this file for compilation
#define MICROPROFILE_IMPL 1
#include "common/microprofile.h"
