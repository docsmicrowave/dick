#pragma once

#include <array>

extern const std::array<unsigned char, 217276> FontStandard;

