#pragma once

#include <array>

extern const std::array<unsigned char, 172064> FontNintendoExtended;

